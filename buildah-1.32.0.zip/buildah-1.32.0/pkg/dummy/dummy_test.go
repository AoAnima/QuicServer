package dummy

import (
	"testing"
)

func TestDummy(t *testing.T) {
}
